
public class MiClase {
	public int x;
	MiClase(int x)
	{
		this.x = x;
	}
	
	//devuelve "x" multiplicado por dos
	int getXPor2()
	{
		return (x * 2);
	}
	
	//devuelve la suma de "x" y "y"
	int getXMasY(int y)
	{
		return (x + y) ;
	}
}
